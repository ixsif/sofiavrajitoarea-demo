/* Vrăjitoarea Sofia: design demo. All copy lives in T (RO/EN) so it is easy to update. */
(() => {
  "use strict";
  const WA = { ro: { num: "40745762879", msg: "Bună ziua, Sofia! Aș dori mai multe informații despre serviciile dumneavoastră și aș dori să programez o ședință." }, en: { num: "44755233911", msg: "Hello Sofia! I would like more information about your services and would like to book a reading." } };
  const waUrl = (l) => `https://wa.me/${WA[l].num}?text=${encodeURIComponent(WA[l].msg)}`;

  const T = {
    ro: {
      title: "Vrăjitoarea Sofia — Tarot, tradiții ancestrale și îndrumare spirituală",
      desc: "Vrăjitoarea Sofia: peste 40 de ani de experiență în tarot, tradiții ancestrale și îndrumare spirituală. Programează-ți ședința pe WhatsApp.",
      skip: "Sari la conținut", demo: "Previzualizare de design — formularele și rezervările nu sunt active; butoanele WhatsApp deschid conversații reale.",
      brand: "Vrăjitoarea Sofia", nav_home: "Acasă", nav_about: "Despre Sofia", nav_services: "Servicii", nav_tarot: "Citirea în cărți", nav_testi: "Mărturii", nav_contact: "Contact",
      hero_eyebrow: "Tarot · Tradiții ancestrale · Îndrumare spirituală", hero_title: "Vrăjitoarea Sofia", hero_tag: "Harul care schimbă destine",
      hero_lead: "De peste 40 de ani, numele Vrăjitoarei Sofia este cunoscut în România și dincolo de hotare. O femeie cu har din naștere, dedicată tradițiilor ancestrale, tarotului și îndrumării spirituale.",
      cta_book: "Programează-ți ședința", cta_story: "Descoperă povestea Sofiei",
      svc_eyebrow: "Servicii", svc_title: "Puterea Sofiei – Magie, Har și Adevăr",
      about_eyebrow: "Despre Sofia", about_title: "Femeia cu suflet mare și har divin",
      about_p1: "Prin tradițiile transmise din generație în generație și experiența acumulată de-a lungul a peste 40 de ani, Sofia și-a dedicat activitatea îndrumării celor care caută răspunsuri, liniște și speranță.",
      about_p2: "Ea nu judecă și nu întreabă de ce. Își întâmpină fiecare persoană cu discreție, respect și dorința de a oferi sprijin spiritual.",
      stat_years: "ani de experiență", stat_aces: "Ași de tarot în ședințe", about_alt: "Vrăjitoarea Sofia într-un fotoliu auriu, cu un glob de cristal în mâini",
      svc_more: "Află mai multe", steps_title: "Cum decurge", svc_cta: "Scrie-i Sofiei pe WhatsApp", scene_white: "MAGIA ALBĂ", scene_black: "MAGIA NEAGRĂ",
      steps: ["Îi scrii Sofiei pe WhatsApp.", "Povestești pe scurt ce te preocupă.", "Stabiliți împreună ședința potrivită."],
      svc_note: "Pentru reflecție personală și îndrumare spirituală. Nu se garantează rezultate și nu înlocuiește sfatul medical, juridic sau financiar.",
      svcdetail: [
        ["Sofia amestecă și deschide cărțile, apoi interpretează simbolurile pentru întrebările tale despre iubire, familie, carieră și drumul vieții.", "Fiecare ședință este o conversație: tu pui întrebările, iar Sofia îți oferă interpretări și îndrumare spirituală, cu răbdare și fără judecată."],
        ["În tradiția populară, magia albă este legată de protecție, armonie și binecuvântare, iar magia neagră de dezlegări și de înlăturarea influențelor negative. Sofia le practică așa cum le-a învățat din tradițiile transmise în familie.", "Fiecare ritual îți este explicat înainte să înceapă, iar tu hotărăști dacă vrei să continui. Totul se desfășoară cu discreție și respect."],
        ["Îndrumare spirituală pentru întrebările inimii: relația de cuplu, împăcări și redescoperirea armoniei.", "Sofia te ascultă fără să te judece și te ajută să vezi mai clar ce simți și ce îți dorești. Nu se promit reveniri sau rezultate."],
        ["Protecții spirituale, talismane și tradiții ancestrale dedicate liniștii și echilibrului sufletesc.", "Sofia îți explică semnificația fiecărui talisman sau ritual de protecție și cum îl poți păstra, ca punct de sprijin în viața ta de zi cu zi."],
        ["Îndrumare spirituală pentru noroc, prosperitate, succes în afaceri și noi oportunități.", "Cărțile și tradițiile ancestrale sunt folosite ca punct de reflecție asupra deciziilor tale. Nu se promit câștiguri sau rezultate financiare."],
        ["Îndrumare spirituală pentru armonia familiei, relații mai bune și liniștea căminului.", "Sofia te ajută să privești cu mai multă calm și înțelegere relațiile din familie, într-o discuție discretă și respectuoasă."],
      ],
      cardnames: { cups: "ASUL DE CUPE", swords: "ASUL DE SPADE", wands: "ASUL DE BASTOANE", pentacles: "ASUL DE PENTACLE" }, cardhint: "Atinge o carte ca s-o întorci",
      magic_eyebrow: "Magie albă și neagră", magic_title: "Ritualuri și tradiții ancestrale",
      magic_p1: "Sofia practică magia albă și neagră așa cum a învățat-o din tradițiile transmise în familie: ritualuri spirituale pentru dezlegări, protecție și îndrumare.",
      magic_p2: "Fiecare ritual este discutat în prealabil, cu respect și discreție. Nu se promit rezultate; scopul este sprijin spiritual și liniște sufletească.",
      magic_chips: ["Dezlegări", "Protecție spirituală", "Iubire și împăcare", "Noroc și prosperitate", "Armonie în familie", "Talismane"], magic_cta: "Întreab-o pe Sofia despre ritualuri",
      g_eyebrow: "Galerie", g_title: "Din lumea Sofiei", g_text: "Câteva imagini din spațiul și tradițiile Sofiei.", g_open: "Mărește imaginea",
      gallery: ["Sofia la altarul cu lumânări aprinse", "Sofia cu un coș cu ierburi și lumânări, lângă râu", "Sofia în grădină, noaptea, în fața unui candelabru aprins", "Sofia ținând un craniu decorat, la altar", "Sofia în costum popular, cu o scoică mare în mâini", "Sofia într-o cameră tradițională, cu ierburi și lumânări roșii"],
      tarot_eyebrow: "Citirea în cărți", tarot_title: "Ce îți rezervă cărțile destinului?", tarot_intro: "Vrăjitoarea Sofia îți deschide cărțile și îți oferă interpretări și îndrumare spirituală despre:", tarot_cta: "Rezervă o citire în cărți",
      why_eyebrow: "De ce Sofia", why_title: "Încredere, tradiție și discreție",
      t_eyebrow: "Mărturii", t_title: "Ce spun cei care au apelat la Sofia", t_note: "Mărturii demonstrative — vor fi înlocuite cu păreri reale ale clienților, cu acordul lor.",
      c_eyebrow: "Contact", c_title: "Când ai nevoie de liniște, Sofia te ascultă", c_text: "Scrie-i pe WhatsApp în limba în care te simți cel mai confortabil. Discuția rămâne confidențială.",
      wa_ro_btn: "Programează-ți ședința pe WhatsApp", wa_en_btn: "Book Your Reading on WhatsApp", world: "Sunați din orice colț al lumii v-ați afla!",
      disclaimer_short: "Citirile în cărți și serviciile spirituale sunt pentru reflecție personală și îndrumare spirituală. Nu înlocuiesc sfatul medical, psihologic, juridic sau financiar și nu garantează rezultate.",
      disclaimer_long: "Citirile în cărți și serviciile spirituale sunt oferite pentru reflecție personală și îndrumare spirituală. Nu constituie sfat medical, psihologic, juridic sau financiar și nu înlocuiesc consultul unui specialist. Nu se garantează rezultate. Dacă treci printr-o criză sau ai nevoie de ajutor medical, contactează un medic sau serviciile de urgență.",
      foot_desc: "Tarot, tradiții ancestrale și îndrumare spirituală, cu discreție și respect, de peste 40 de ani.", foot_nav: "Navigare", foot_contact: "Contact WhatsApp",
      rights: "Toate drepturile rezervate.", privacy: "Politica de confidențialitate", terms: "Termeni și condiții", fanlabel: "Cei patru Ași din tarot",
      services: [
        ["cards", "Citiri în tarot", "Descoperă ce îți rezervă viitorul prin intermediul cărților de tarot. Sofia oferă îndrumare spirituală și interpretări privind iubirea, familia, cariera și drumul vieții."],
        ["pentacle", "Magie albă și neagră", "Tradiții ancestrale și ritualuri spirituale pentru dezlegări, protecție și îndrumare."],
        ["heart", "Iubire și relații", "Îndrumare spirituală pentru iubire, relații, împăcări și redescoperirea armoniei în cuplu."],
        ["shield", "Protecție spirituală", "Protecții spirituale, talismane și tradiții ancestrale dedicate liniștii și echilibrului sufletesc."],
        ["clover", "Noroc și prosperitate", "Îndrumare spirituală pentru noroc, prosperitate, succes în afaceri și noi oportunități."],
        ["house", "Armonie în familie", "Îndrumare spirituală pentru armonia familiei, relații mai bune și liniștea căminului."],
      ],
      heroicons: [["cards", "Tarot și tradiții ancestrale"], ["pentacle", "Magie albă și neagră"], ["heart", "Iubire și relații"], ["shield", "Protecție spirituală"], ["clover", "Noroc și prosperitate"], ["house", "Armonie în familie"]],
      tarot_list: ["Cine ești cu adevărat și care este drumul tău în viață.", "Când și cum ar putea prinde contur dorințele tale.", "Posibile succese, provocări și schimbări în viitorul apropiat.", "Relațiile tale și oamenii din jurul tău.", "Întrebările care îți apasă sufletul."],
      why: [["clock", "Peste 40 de ani de experiență"], ["hourglass", "Tradiții ancestrale"], ["cards", "Citiri de tarot"], ["lock", "Discreție și confidențialitate"], ["globe", "Apeluri din orice colț al lumii"]],
      testi: ["Aici va apărea mărturia unui client real, cu numele și acordul său.", "Spațiu rezervat pentru o părere sinceră despre o ședință cu Sofia.", "Mărturiile reale vor fi adăugate pe măsură ce sunt primite."], testi_tag: "Mărturie demonstrativă",
      modal: { privacy: ["Politica de confidențialitate", ["Variantă demonstrativă, de completat cu un jurist înainte de publicare.", "Acest site nu colectează date prin formulare. Când folosești butoanele WhatsApp, conversația are loc în aplicația WhatsApp, supusă politicii acesteia.", "Discuțiile cu Sofia sunt tratate confidențial. Datele tale nu sunt vândute sau transmise terților."]], terms: ["Termeni și condiții", ["Variantă demonstrativă, de completat cu un jurist înainte de publicare.", "Serviciile sunt oferite pentru reflecție personală și îndrumare spirituală. Nu constituie sfat medical, psihologic, juridic sau financiar și nu garantează rezultate.", "Programările se stabilesc direct cu Sofia pe WhatsApp. Prețurile și condițiile se convin în conversație."]] },
    },
    en: {
      title: "Witch Sofia — Tarot, Ancestral Traditions and Spiritual Guidance",
      desc: "Witch Sofia: over 40 years of experience in tarot, ancestral traditions and spiritual guidance. Book your reading on WhatsApp, from anywhere in the world.",
      skip: "Skip to content", demo: "Design preview — forms and bookings are not active; the WhatsApp buttons open real conversations.",
      brand: "Witch Sofia", nav_home: "Home", nav_about: "About Sofia", nav_services: "Services", nav_tarot: "Tarot Reading", nav_testi: "Testimonials", nav_contact: "Contact",
      hero_eyebrow: "Tarot · Ancestral traditions · Spiritual guidance", hero_title: "Witch Sofia", hero_tag: "The Gift That Changes Destinies",
      hero_lead: "For over 40 years, Sofia's name has been known across Romania and beyond. A woman devoted to ancestral traditions, tarot and spiritual guidance.",
      cta_book: "Book Your Reading", cta_story: "Discover Sofia's Story",
      svc_eyebrow: "Services", svc_title: "Sofia's Gift – Magic, Spirituality and Guidance",
      about_eyebrow: "About Sofia", about_title: "A Woman with a Special Spiritual Gift",
      about_p1: "Through traditions passed down from generation to generation and over 40 years of experience, Sofia has dedicated herself to guiding those searching for answers, peace and hope.",
      about_p2: "She does not judge. She welcomes everyone with discretion, respect and a genuine desire to offer spiritual support.",
      stat_years: "years of experience", stat_aces: "tarot Aces in each reading", about_alt: "Witch Sofia seated in a gilded chair, holding a crystal globe",
      svc_more: "Learn more", steps_title: "How it works", svc_cta: "Message Sofia on WhatsApp", scene_white: "WHITE MAGIC", scene_black: "BLACK MAGIC",
      steps: ["You message Sofia on WhatsApp.", "You briefly share what is on your mind.", "Together you arrange the right session."],
      svc_note: "For personal reflection and spiritual guidance. No results are guaranteed and this is not medical, legal or financial advice.",
      svcdetail: [
        ["Sofia shuffles and opens the cards, then interprets their symbols for your questions about love, family, career and life's journey.", "Every reading is a conversation: you ask, and Sofia offers interpretations and spiritual guidance, patiently and without judgement."],
        ["In folk tradition, white magic is linked with protection, harmony and blessing, while black magic is linked with cleansing and removing negative influences. Sofia practises both as she learned them from traditions passed down in her family.", "Every ritual is explained to you before it begins, and you decide whether to continue. Everything is done with discretion and respect."],
        ["Spiritual guidance for matters of the heart: your relationship, reconciliation and rediscovering harmony.", "Sofia listens without judging and helps you see more clearly what you feel and what you want. No reunions or outcomes are promised."],
        ["Spiritual protection, talismans and ancestral traditions dedicated to peace and emotional balance.", "Sofia explains the meaning of each talisman or protective ritual and how to keep it, as a point of support in your everyday life."],
        ["Spiritual guidance concerning luck, prosperity, business success and new opportunities.", "The cards and ancestral traditions are used as a point of reflection on your decisions. No gains or financial results are promised."],
        ["Spiritual guidance for family harmony, stronger relationships and peace at home.", "Sofia helps you look at family relationships with more calm and understanding, in a discreet and respectful conversation."],
      ],
      cardnames: { cups: "ACE OF CUPS", swords: "ACE OF SWORDS", wands: "ACE OF WANDS", pentacles: "ACE OF PENTACLES" }, cardhint: "Tap a card to turn it over",
      magic_eyebrow: "White and Black Magic", magic_title: "Rituals and Ancestral Traditions",
      magic_p1: "Sofia practises white and black magic as it was handed down through her family: spiritual rituals for cleansing, protection and guidance.",
      magic_p2: "Every ritual is discussed beforehand, with respect and discretion. No results are promised; the aim is spiritual support and peace of mind.",
      magic_chips: ["Spiritual cleansing", "Spiritual protection", "Love and reconciliation", "Luck and prosperity", "Family harmony", "Talismans"], magic_cta: "Ask Sofia About Rituals",
      g_eyebrow: "Gallery", g_title: "Inside Sofia's World", g_text: "A few glimpses of Sofia's space and traditions.", g_open: "Enlarge image",
      gallery: ["Sofia at her altar with lit candles", "Sofia with a basket of herbs and candles by the river", "Sofia in the garden at night, before a lit candelabra", "Sofia holding a decorated skull at the altar", "Sofia in traditional dress, holding a large shell", "Sofia in a traditional room with herbs and red candles"],
      tarot_eyebrow: "Tarot Reading", tarot_title: "What Do the Cards of Destiny Hold for You?", tarot_intro: "Witch Sofia opens the cards for you and offers interpretations and spiritual guidance about:", tarot_cta: "Book Your Tarot Reading",
      why_eyebrow: "Why Sofia", why_title: "Trust, Tradition and Discretion",
      t_eyebrow: "Testimonials", t_title: "What People Say About Sofia", t_note: "Demonstration testimonials: they will be replaced with genuine client feedback, with their consent.",
      c_eyebrow: "Contact", c_title: "When You Need Clarity, Sofia Listens", c_text: "Message her on WhatsApp in the language you feel most comfortable with. Your conversation stays confidential.",
      wa_ro_btn: "Programează-ți ședința pe WhatsApp", wa_en_btn: "Book Your Reading on WhatsApp", world: "Call from anywhere in the world!",
      disclaimer_short: "Tarot readings and spiritual services are for personal reflection and spiritual guidance. They are not a substitute for medical, psychological, legal or financial advice, and no results are guaranteed.",
      disclaimer_long: "Tarot readings and spiritual services are offered for personal reflection and spiritual guidance. They are not medical, psychological, legal or financial advice and do not replace consulting a qualified professional. No results are guaranteed. If you are in crisis or need medical help, please contact a doctor or the emergency services.",
      foot_desc: "Tarot, ancestral traditions and spiritual guidance, offered with discretion and respect for over 40 years.", foot_nav: "Navigation", foot_contact: "WhatsApp contact",
      rights: "All rights reserved.", privacy: "Privacy Policy", terms: "Terms and Conditions", fanlabel: "The four tarot Aces",
      services: [
        ["cards", "Tarot Readings", "Explore the possibilities ahead through tarot readings. Sofia offers spiritual guidance and interpretations concerning love, family, career and life's journey."],
        ["pentacle", "White and Black Magic", "Ancestral traditions and spiritual rituals for spiritual cleansing, protection and guidance."],
        ["heart", "Love and Relationships", "Spiritual guidance concerning love, relationships, reconciliation and restoring harmony."],
        ["shield", "Spiritual Protection", "Spiritual protection, talismans and ancestral traditions dedicated to peace and emotional balance."],
        ["clover", "Luck and Prosperity", "Spiritual guidance concerning luck, prosperity, business success and new opportunities."],
        ["house", "Family Harmony", "Spiritual guidance for family harmony, stronger relationships and peace at home."],
      ],
      heroicons: [["cards", "Tarot & Ancestral Traditions"], ["pentacle", "White & Black Magic"], ["heart", "Love & Relationships"], ["shield", "Spiritual Protection"], ["clover", "Luck & Prosperity"], ["house", "Family Harmony"]],
      tarot_list: ["Who you truly are and what your path in life may be.", "When and how your wishes may take shape.", "Possible successes, challenges and changes in the near future.", "Your relationships and the people around you.", "The questions weighing on your heart."],
      why: [["clock", "Over 40 Years of Experience"], ["hourglass", "Ancestral Traditions"], ["cards", "Tarot Readings"], ["lock", "Discretion and Privacy"], ["globe", "International Calls"]],
      testi: ["A genuine client testimonial will appear here, with their name and consent.", "Space reserved for an honest opinion about a reading with Sofia.", "Real testimonials will be added as they are received."], testi_tag: "Demonstration testimonial",
      modal: { privacy: ["Privacy Policy", ["Demonstration draft, to be completed with legal advice before publishing.", "This site does not collect data through forms. When you use the WhatsApp buttons, the conversation takes place in the WhatsApp app and is subject to its policy.", "Conversations with Sofia are treated confidentially. Your details are not sold or passed to third parties."]], terms: ["Terms and Conditions", ["Demonstration draft, to be completed with legal advice before publishing.", "Services are offered for personal reflection and spiritual guidance. They are not medical, psychological, legal or financial advice and no results are guaranteed.", "Bookings are arranged directly with Sofia on WhatsApp. Prices and conditions are agreed in conversation."]] },
    },
  };

  /* ---------- icons ---------- */
  const IC = {
    cards: '<rect x="3" y="5" width="11" height="15" rx="2"/><path d="M8 5l3-2 9 4-4 13-3 1"/>',
    pentacle: '<circle cx="12" cy="12" r="9"/><path d="M12 4l5.2 15L4 9.7h16L6.8 19z"/>',
    heart: '<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
    shield: '<path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    clover: '<circle cx="9" cy="9" r="3.2"/><circle cx="15" cy="9" r="3.2"/><circle cx="9" cy="15" r="3.2"/><circle cx="15" cy="15" r="3.2"/><path d="M12 12v9"/>',
    house: '<path d="M4 11l8-7 8 7v9H4z"/><path d="M10 20v-6h4v6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    hourglass: '<path d="M6 3h12M6 21h12M7 3c0 6 5 6 5 9s-5 3-5 9M17 3c0 6-5 6-5 9s5 3 5 9"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    star: '<path d="M12 3l2.4 6.2L21 10l-5 4.2L17.5 21 12 17.4 6.5 21 8 14.2 3 10l6.6-.8z"/>',
  };
  const icon = (n) => `<svg viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;

  /* ---------- original illustrated Aces (animated parts carry classes, see extra.css) ---------- */
  /* ---------- illustrated Aces v2: suit-coloured skies, hands-free symbols, landscapes, ornate frame, flip faces ---------- */
  const DEFS = '<defs><linearGradient id="gGold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F3CF86"/><stop offset=".55" stop-color="#D6A044"/><stop offset="1" stop-color="#8a5a1c"/></linearGradient>'
    + '<linearGradient id="skycups" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f2f66"/><stop offset=".55" stop-color="#26307a"/><stop offset="1" stop-color="#150b2e"/></linearGradient>'
    + '<linearGradient id="skyswords" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a1252"/><stop offset=".55" stop-color="#5a1a52"/><stop offset="1" stop-color="#160a26"/></linearGradient>'
    + '<linearGradient id="skywands" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f3a46"/><stop offset=".55" stop-color="#2d4a2a"/><stop offset="1" stop-color="#170d1f"/></linearGradient>'
    + '<linearGradient id="skypentacles" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2a14"/><stop offset=".55" stop-color="#52283c"/><stop offset="1" stop-color="#160a22"/></linearGradient>'
    + '<linearGradient id="gSteel" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#9aa3b8"/><stop offset=".5" stop-color="#f1f4fb"/><stop offset="1" stop-color="#8d96ac"/></linearGradient>'
    + '<radialGradient id="gGlow"><stop offset="0" stop-color="#FFE9A8" stop-opacity=".85"/><stop offset="1" stop-color="#FFE9A8" stop-opacity="0"/></radialGradient>'
    + '<linearGradient id="gShine" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".6"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
    + '<linearGradient id="gHolo" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff8de0" stop-opacity="0"/><stop offset=".35" stop-color="#8de0ff" stop-opacity=".22"/><stop offset=".65" stop-color="#ffe98d" stop-opacity=".22"/><stop offset="1" stop-color="#c58dff" stop-opacity="0"/></linearGradient>'
    + '<pattern id="bp" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M10 2l3 8-3 8-3-8z" fill="none" stroke="#D6A044" stroke-opacity=".28"/></pattern></defs>';
  const rays = (n = 18) => `<g class="rays" stroke="#F3CF86" stroke-width="1.2" opacity=".5">${Array.from({ length: n }, (_, i) => { const a = (i / n) * Math.PI * 2; return `<line x1="${120 + Math.cos(a) * 40}" y1="${190 + Math.sin(a) * 40}" x2="${120 + Math.cos(a) * 118}" y2="${190 + Math.sin(a) * 118}"/>`; }).join("")}</g>`;
  const cloud = (x, y, s = 1) => `<g transform="translate(${x} ${y}) scale(${s})" fill="#cfc4ea" opacity=".9"><ellipse cx="0" cy="0" rx="26" ry="10"/><ellipse cx="-16" cy="-6" rx="14" ry="9"/><ellipse cx="12" cy="-8" rx="16" ry="10"/></g>`;
  const mountains = '<path d="M14 330l44-52 32 36 30-50 36 58 36-40 34 48z" fill="#2a1a56" opacity=".85"/><path d="M14 336l60-34 40 24 40-30 60 40z" fill="#3a2670" opacity=".7"/>';
  const ART = {
    cups: () => `${rays()}<circle cx="120" cy="190" r="92" fill="url(#gGlow)" class="glow-pulse"/>${cloud(52, 118)}${cloud(192, 150, .8)}${mountains}
      <g class="dove"><ellipse cx="120" cy="92" rx="15" ry="8" fill="#fff"/><path d="M106 90q-16-22-30-12 16 6 30 18zM134 90q16-22 30-12-16 6-30 18z" fill="#f4f2ff"/><circle cx="134" cy="87" r="5.5" fill="#fff"/><path d="M139 87l7 2-7 2z" fill="#D6A044"/><path d="M106 94l-10 8 12-3z" fill="#e6e1f7"/></g>
      <circle cx="120" cy="119" r="5" fill="#F3CF86"/><path d="M118 119h4M120 117v4" stroke="#8a5a1c" stroke-width="1"/>
      <path d="M76 142h88q0 64-44 78-44-14-44-78z" fill="url(#gGold)" stroke="#6e4814" stroke-width="2"/><ellipse cx="120" cy="142" rx="44" ry="8" fill="#FFE9A8" opacity=".55"/>
      <circle cx="98" cy="172" r="5" fill="#c1121f" stroke="#FFE9A8" stroke-width="1"/><circle cx="120" cy="184" r="5.5" fill="#1d6fd6" stroke="#FFE9A8" stroke-width="1"/><circle cx="142" cy="172" r="5" fill="#2bb673" stroke="#FFE9A8" stroke-width="1"/>
      <rect x="113" y="220" width="14" height="38" rx="4" fill="url(#gGold)" stroke="#6e4814"/><path d="M88 272q32-22 64 0v6H88z" fill="url(#gGold)" stroke="#6e4814" stroke-width="1.5"/>
      <g stroke="#9fd0ff" stroke-width="2.2" fill="none" opacity=".9">${[80, 96, 144, 160].map((x, i) => `<path class="stream" d="M${x} 148q${x < 120 ? -8 : 8} 60 ${x < 120 ? -6 : 6} 140" style="animation-delay:${-i * 0.3}s"/>`).join("")}</g>
      ${[82, 100, 120, 140, 158].map((x, i) => `<circle class="drop" cx="${x}" cy="150" r="3.2" fill="#cfe8ff" style="animation-delay:${-i * 0.5}s"/>`).join("")}
      <ellipse cx="120" cy="306" rx="92" ry="12" fill="#2e5fa8" opacity=".8"/>${[0, 1, 2].map((i) => `<ellipse class="rip" cx="${100 + i * 24}" cy="306" rx="26" ry="5" fill="none" stroke="#bfe0ff" stroke-width="1.4" style="animation-delay:${-i * 1.1}s"/>`).join("")}
      <g fill="#f7c6e0" stroke="#b05a8c" stroke-width=".8"><path d="M74 302q6-14 12 0q-6 6-12 0zM86 302q8-12 14 2q-8 4-14-2z"/><path d="M158 304q6-14 12 0q-6 6-12 0zM170 304q8-12 14 2q-8 4-14-2z"/></g>`,
    swords: () => `${rays(14)}<circle cx="120" cy="190" r="92" fill="url(#gGlow)" class="glow-pulse"/>${cloud(48, 120)}${cloud(196, 140, .85)}${mountains}
      ${Array.from({ length: 9 }, (_, i) => { const a = Math.PI * (0.18 + i * 0.083), sx = i % 1 === 0 ? 1 : 1; return `<ellipse cx="${120 - Math.cos(a) * 42}" cy="${70 + Math.sin(a) * 38}" rx="7" ry="3" fill="#6c9a3a" stroke="#2f4a14" stroke-width=".8" transform="rotate(${(a * 57.3) - 90} ${120 - Math.cos(a) * 42} ${70 + Math.sin(a) * 38})"/><ellipse cx="${120 + Math.cos(a) * 42}" cy="${70 + Math.sin(a) * 38}" rx="7" ry="3" fill="#6c9a3a" stroke="#2f4a14" stroke-width=".8" transform="rotate(${90 - (a * 57.3)} ${120 + Math.cos(a) * 42} ${70 + Math.sin(a) * 38})"/>`; }).join("")}
      <path d="M98 66l6-26 10 16 6-22 6 22 10-16 6 26z" fill="url(#gGold)" stroke="#6e4814" stroke-width="1.5"/><circle cx="120" cy="36" r="3" fill="#c1121f"/>
      <path d="M120 70l9 18v158h-18V88z" fill="url(#gSteel)" stroke="#5b6377" stroke-width="1.5"/><path d="M120 92v150" stroke="#7c86a0" stroke-width="1.2"/><rect class="gleam" x="110" y="80" width="20" height="40" fill="url(#gShine)" opacity="0"/>
      <path d="M82 246q38-14 76 0v12q-38-10-76 0z" fill="url(#gGold)" stroke="#6e4814" stroke-width="1.5"/><circle cx="120" cy="252" r="4" fill="#1d6fd6"/><rect x="115" y="258" width="10" height="44" rx="3" fill="#6e4814"/><path d="M115 266h10M115 276h10M115 286h10" stroke="#d6a044" stroke-width="1.2"/><circle cx="120" cy="310" r="9" fill="url(#gGold)" stroke="#6e4814" stroke-width="1.5"/>
      ${[70, 82, 158, 172, 94, 146].map((x, i) => `<path class="yod" d="M${x} ${112 + i * 10}q-4 8 0 10q4-2 0-10z" fill="#F3CF86" style="animation-delay:${-i * 0.6}s"/>`).join("")}`,
    wands: () => `${rays(16)}<circle cx="120" cy="190" r="92" fill="url(#gGlow)" class="glow-pulse"/>${cloud(46, 124)}${cloud(194, 112, .8)}
      <path d="M14 322q70-40 120-6t92-26v60H14z" fill="#2b4a2a" opacity=".9"/><path d="M14 334q80-24 130-4t82-14v48H14z" fill="#1f3a24"/>
      <g fill="#4a3a8a" opacity=".95"><rect x="168" y="278" width="40" height="30"/><rect x="164" y="268" width="10" height="14"/><rect x="202" y="268" width="10" height="14"/><rect x="180" y="262" width="16" height="22"/><path d="M164 268l5-8 5 8zM202 268l5-8 5 8zM180 262l8-10 8 10z" fill="#6a4ab0"/></g>${[174, 188, 200].map((x, i) => `<rect class="twinkle" x="${x}" y="290" width="4" height="6" fill="#FFE9A8" style="animation-delay:${-i * .7}s"/>`).join("")}
      <g transform="rotate(-9 120 200)"><path d="M112 70q8-8 16 0l-2 250q-6 6-12 0z" fill="#7a4a1c" stroke="#3e240c" stroke-width="2"/><path d="M116 76l-1 240" stroke="#b9823f" stroke-width="2" opacity=".8"/><ellipse cx="120" cy="150" rx="9" ry="4" fill="#3e240c"/><ellipse cx="120" cy="230" rx="9" ry="4" fill="#3e240c"/>
      ${[[118, -1], [160, 1], [196, -1], [248, 1]].map(([y, d], i) => `<path class="leaf" d="M120 ${y}q${d * 46} -28 ${d * 62} -4q${-d * 22} 24 ${-d * 62} 4z" fill="#6c9a3a" stroke="#2f4a14" stroke-width="1.5" style="animation-delay:${-i * 0.8}s"/>`).join("")}<path class="leaf" d="M120 78q-14-26 0-44 14 18 0 44z" fill="#8fbf45" stroke="#2f4a14" stroke-width="1.5"/></g>
      ${[70, 100, 150, 176, 60, 188].map((x, i) => `<path class="fall" d="M${x} 90q6-8 12 0q-6 8-12 0z" fill="#9fcf55" stroke="#2f4a14" stroke-width=".8" style="animation-delay:${-i * 0.9}s"/>`).join("")}
      ${[92, 112, 134, 150].map((x, i) => `<circle class="spark" cx="${x}" cy="${120 + i * 14}" r="3" fill="#FFE9A8" style="animation-delay:${-i * 0.8}s"/>`).join("")}`,
    pentacles: () => `${rays(20)}<circle cx="120" cy="190" r="92" fill="url(#gGlow)" class="glow-pulse"/>${cloud(50, 112)}${cloud(192, 126, .8)}
      <path d="M44 330V190q0-70 76-78t76 78v140" fill="none" stroke="#D6A044" stroke-width="3" opacity=".8"/><path d="M52 330V194q0-60 68-66t68 66v136" fill="none" stroke="#8a5a1c" stroke-width="1.5" opacity=".8"/>
      ${Array.from({ length: 16 }, (_, i) => { const a = Math.PI + (i / 15) * Math.PI; const cx = 120 + Math.cos(a) * 76, cy = 188 + Math.sin(a) * 78; return `<circle class="twinkle" cx="${cx}" cy="${cy}" r="3.6" fill="${i % 2 ? "#ff9ec4" : "#fff4d0"}" style="animation-delay:${-i * 0.3}s"/>`; }).join("")}
      <circle cx="120" cy="190" r="62" fill="url(#gGold)" stroke="#6e4814" stroke-width="2.5"/><circle cx="120" cy="190" r="52" fill="#1b1030" stroke="#F3CF86" stroke-width="1.5"/>
      <g class="spin"><circle cx="120" cy="190" r="57" fill="none" stroke="#FFE9A8" stroke-width="1.5" stroke-dasharray="3 7"/></g><g class="spin rev"><circle cx="120" cy="190" r="46" fill="none" stroke="#D6A044" stroke-width="1" stroke-dasharray="10 6"/></g>
      <path class="pulse-star" d="M120 144l27 82-70-50h86l-70 50z" fill="rgba(243,207,134,.18)" stroke="#F3CF86" stroke-width="2.6" stroke-linejoin="round"/><circle cx="120" cy="190" r="7" fill="#FFE9A8" class="twinkle"/>
      ${[[120, 140], [160, 175], [146, 222], [94, 222], [80, 175]].map(([x, y], i) => `<circle cx="${x}" cy="${y}" r="3.2" fill="${["#c1121f", "#1d6fd6", "#2bb673", "#F3CF86", "#9b5de5"][i]}" class="twinkle" style="animation-delay:${-i * 0.5}s"/>`).join("")}
      <path d="M14 330q60-26 106-10t106-12v60H14z" fill="#3a2a14" opacity=".9"/><g fill="#fff4d0" stroke="#b9823f" stroke-width=".8"><path d="M70 322q4-18 9 0zM86 324q4-16 8 0zM160 324q4-18 9 0zM176 322q4-16 8 0z"/></g>`,
  };
  const TITLES = { cups: "ASUL DE CUPE", swords: "ASUL DE SPADE", wands: "ASUL DE BASTOANE", pentacles: "ASUL DE PENTACLE" };
  const ROMAN = "I";
  const twinkles = Array.from({ length: 22 }, (_, i) => { const x = 22 + ((i * 53) % 196), y = 24 + ((i * 97) % 300); return `<circle class="twinkle" cx="${x}" cy="${y}" r="${i % 3 ? 1 : 1.6}" fill="#F3CF86" style="animation-delay:${-(i % 7) * 0.4}s"/>`; }).join("");
  const moon = (x, k) => { const y = 64; const ph = [`<circle cx="${x}" cy="${y}" r="6" fill="none" stroke="#D6A044"/>`, `<circle cx="${x}" cy="${y}" r="6" fill="none" stroke="#D6A044" stroke-opacity=".5"/><path d="M${x} ${y - 6}A6 6 0 1 1 ${x} ${y + 6}A3 6 0 1 0 ${x} ${y - 6}z" fill="#F3CF86"/>`, `<circle cx="${x}" cy="${y}" r="6" fill="#F3CF86"/>`, `<circle cx="${x}" cy="${y}" r="6" fill="none" stroke="#D6A044" stroke-opacity=".5"/><path d="M${x} ${y - 6}A6 6 0 1 0 ${x} ${y + 6}A3 6 0 1 1 ${x} ${y - 6}z" fill="#F3CF86"/>`, `<circle cx="${x}" cy="${y}" r="6" fill="none" stroke="#D6A044"/>`]; return ph[k]; };
  const corner = (tx, ty, sx, sy) => `<g transform="translate(${tx} ${ty}) scale(${sx} ${sy})" fill="none" stroke="#F3CF86" stroke-width="1.4"><path d="M0 22Q0 0 22 0"/><path d="M5 22Q5 5 22 5" opacity=".6"/><path d="M0 0l4 -4 4 4-4 4z" fill="#D6A044" stroke="none"/></g>`;
  function cardSVG(kind) {
    return `<svg viewBox="0 0 240 400" role="img" aria-label="${TITLES[kind]}">${DEFS}
      <rect x="3" y="3" width="234" height="394" rx="14" fill="url(#sky${kind})" stroke="url(#gGold)" stroke-width="3"/><rect x="12" y="12" width="216" height="376" rx="8" fill="none" stroke="#D6A044" stroke-opacity=".7"/><rect x="17" y="17" width="206" height="366" rx="6" fill="none" stroke="#D6A044" stroke-opacity=".4" stroke-dasharray="2 5"/>
      ${corner(20, 20, 1, 1)}${corner(220, 20, -1, 1)}${corner(20, 380, 1, -1)}${corner(220, 380, -1, -1)}
      ${twinkles}<rect x="98" y="22" width="44" height="24" rx="5" fill="#120a1c" stroke="#D6A044" stroke-width="1.2"/><text x="120" y="39" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="14" fill="#F3CF86">${ROMAN}</text>
      ${[70, 95, 120, 145, 170].map((x, k) => moon(x, k)).join("")}
      <g>${ART[kind]()}</g>
      <rect x="22" y="346" width="196" height="38" rx="6" fill="#120a1c" stroke="#D6A044" stroke-width="1.5"/><text class="ctitle" data-k="${kind}" x="120" y="370" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="13" letter-spacing="1.5" fill="#F3CF86">${TITLES[kind]}</text>
      <rect x="0" y="0" width="240" height="400" rx="14" fill="url(#gHolo)" class="holo"/><rect class="shine" x="0" y="0" width="70" height="400" fill="url(#gShine)" transform="skewX(-12)"/></svg>`;
  }
  function backSVG() {
    const pts = Array.from({ length: 24 }, (_, i) => { const a = (i / 24) * Math.PI * 2 - Math.PI / 2, r = i % 2 ? 40 : 74; return `${120 + Math.cos(a) * r},${200 + Math.sin(a) * r}`; }).join(" ");
    return `<svg viewBox="0 0 240 400" aria-hidden="true">${DEFS}<rect x="3" y="3" width="234" height="394" rx="14" fill="#160c26" stroke="url(#gGold)" stroke-width="3"/><rect x="12" y="12" width="216" height="376" rx="8" fill="none" stroke="#D6A044" stroke-opacity=".7"/><rect x="20" y="20" width="200" height="360" rx="6" fill="url(#bp)"/>
      ${corner(20, 20, 1, 1)}${corner(220, 20, -1, 1)}${corner(20, 380, 1, -1)}${corner(220, 380, -1, -1)}
      <circle cx="120" cy="200" r="96" fill="url(#gGlow)" opacity=".5" class="glow-pulse"/><circle cx="120" cy="200" r="88" fill="none" stroke="#D6A044" stroke-width="1.2"/><g class="spin"><circle cx="120" cy="200" r="80" fill="none" stroke="#F3CF86" stroke-width="1" stroke-dasharray="2 6"/></g>
      <g class="spin rev"><polygon points="${pts}" fill="rgba(214,160,68,.12)" stroke="#D6A044" stroke-width="1.2"/></g>
      <circle cx="120" cy="200" r="30" fill="#120a1c" stroke="#F3CF86" stroke-width="1.5"/><path d="M128 178a24 24 0 1 0 6 40 20 20 0 0 1-6-40z" fill="none" stroke="#F3CF86" stroke-width="2.2"/><path d="M134 192l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#F3CF86" class="twinkle"/>
      <rect class="shine" x="0" y="0" width="70" height="400" fill="url(#gShine)" transform="skewX(-12)"/></svg>`;
  }
  const KINDS = ["cups", "swords", "wands", "pentacles"];
  function makeCard(kind, i) {
    const d = document.createElement("div"); d.className = "tcard"; d.style.setProperty("--i", i); d.dataset.kind = kind; d.setAttribute("role", "button"); d.tabIndex = 0;
    d.innerHTML = `<div class="flip"><div class="face front">${cardSVG(kind)}</div><div class="face back">${backSVG()}</div></div>`;
    const toggle = () => d.classList.toggle("show");
    d.addEventListener("click", toggle); d.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });
    return d;
  }
  /* ritual circle for the magic section (draws itself, rotating runes, flickering candles, rising sparks) */
  function buildRitual() {
    const C = 200, pt = (r, deg) => [C + Math.cos((deg * Math.PI) / 180) * r, C + Math.sin((deg * Math.PI) / 180) * r];
    const star = [0, 2, 4, 1, 3, 0].map((k) => pt(118, -90 + k * 72).map((n) => n.toFixed(1)).join(",")).join(" ");
    const runes = Array.from({ length: 16 }, (_, i) => { const [x, y] = pt(158, i * 22.5); return `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${(i * 22.5 + 90).toFixed(1)})"><path d="M0 -8V8M0 -3L5 -8M0 3L5 -2${i % 3 === 0 ? "M-5 0H5" : ""}" stroke="#F3CF86" stroke-width="1.6" fill="none" stroke-linecap="round"/></g>`; }).join("");
    const candles = Array.from({ length: 8 }, (_, i) => { const [x, y] = pt(184, i * 45 + 22.5); return `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)})"><rect x="-3.5" y="-2" width="7" height="22" rx="2" fill="#f3e6c8"/><g class="rflame" style="animation-delay:${-i * 0.35}s"><ellipse cx="0" cy="-8" rx="5" ry="9" fill="url(#rFlame)"/><circle cx="0" cy="-8" r="13" fill="url(#gGlow)" opacity=".7"/></g></g>`; }).join("");
    const sparks = Array.from({ length: 18 }, (_, i) => { const x = C - 70 + ((i * 37) % 140), d = (i * 0.45) % 6; return `<circle class="rspark" cx="${x}" cy="${C + 20}" r="${1.4 + (i % 3) * 0.6}" fill="#FFE9A8" style="animation-delay:${-d}s"/>`; }).join("");
    return `<svg viewBox="0 0 400 400" role="img" aria-hidden="true"><defs><radialGradient id="rGlow"><stop offset="0" stop-color="#8d4fd6" stop-opacity=".55"/><stop offset=".6" stop-color="#3a1a6a" stop-opacity=".25"/><stop offset="1" stop-color="#3a1a6a" stop-opacity="0"/></radialGradient><radialGradient id="rFlame" cx=".5" cy=".75" r=".7"><stop offset="0" stop-color="#fff8d8"/><stop offset=".4" stop-color="#ffd36b"/><stop offset="1" stop-color="#ff7a1e" stop-opacity="0"/></radialGradient><radialGradient id="gGlow"><stop offset="0" stop-color="#FFE9A8" stop-opacity=".85"/><stop offset="1" stop-color="#FFE9A8" stop-opacity="0"/></radialGradient></defs>
      <circle cx="200" cy="200" r="196" fill="url(#rGlow)" class="rpulse"/>
      <g class="rspin"><circle cx="200" cy="200" r="178" fill="none" stroke="#D6A044" stroke-width="1.4" stroke-dasharray="3 9"/></g><circle cx="200" cy="200" r="170" fill="none" stroke="#D6A044" stroke-width="1" opacity=".6"/>
      <g class="rspin rev">${runes}</g><circle cx="200" cy="200" r="146" fill="none" stroke="#D6A044" stroke-width="1.2" opacity=".8"/>
      <polyline class="rdraw" points="${star}" fill="rgba(214,160,68,.06)" stroke="#F3CF86" stroke-width="2.4" stroke-linejoin="round" pathLength="1000"/>
      <circle cx="200" cy="200" r="56" fill="#120a1c" stroke="#D6A044" stroke-width="1.6"/><g class="rspin slowr"><circle cx="200" cy="200" r="46" fill="none" stroke="#F3CF86" stroke-width="1" stroke-dasharray="2 6"/></g>
      <path d="M208 176a26 26 0 1 0 6 44 22 22 0 0 1-6-44z" fill="none" stroke="#F3CF86" stroke-width="2.4"/><circle cx="200" cy="200" r="30" fill="url(#gGlow)" class="rpulse"/>
      ${candles}${sparks}</svg>`;
  }
  /* simplified glyphs shown inside the crystal ball */
  const GLYPH = {
    cups: '<path d="M30 30h40q0 32-20 38-20-6-20-38zM44 68h12v16H44zM34 90q16-10 32 0v4H34z" fill="none" stroke="#FFE9A8" stroke-width="3" stroke-linejoin="round"/>',
    swords: '<path d="M50 8l5 10v56H45V18zM28 74q22-8 44 0v6q-22-6-44 0zM46 82h8v18h-8z" fill="none" stroke="#FFE9A8" stroke-width="3" stroke-linejoin="round"/>',
    wands: '<path d="M46 12q4-4 8 0l-1 86q-3 3-6 0z" fill="none" stroke="#FFE9A8" stroke-width="3"/><path d="M50 40q-20-10-24 4 14 8 24-4zM50 62q22-10 26 4-14 8-26-4z" fill="none" stroke="#FFE9A8" stroke-width="3"/>',
    pentacles: '<circle cx="50" cy="52" r="34" fill="none" stroke="#FFE9A8" stroke-width="3"/><path d="M50 24l16 50L24 44h52L34 74z" fill="none" stroke="#FFE9A8" stroke-width="3" stroke-linejoin="round"/>',
  };

  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  let lang = "ro";
  try { lang = localStorage.getItem("sofia-lang") || ((navigator.language || "").toLowerCase().startsWith("ro") ? "ro" : "ro"); } catch (e) { /* ignore */ }

  /* ---------- static builders ---------- */
  const fan = $("#fan");
  KINDS.forEach((k, i) => fan.appendChild(makeCard(k, i)));
  const mini = $("#mini-cards");
  KINDS.forEach((k, i) => mini.appendChild(makeCard(k, i)));
  $("#ritual").innerHTML = buildRitual();
  const rmotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const fanCards = [...fan.children], miniCards = [...mini.children];
  fanCards.forEach((c, i) => setTimeout(() => c.classList.add("show"), rmotion ? 0 : 1500 + i * 380));
  if (!rmotion) { let n = 0; setInterval(() => { const c = fanCards[n++ % 4]; c.classList.remove("show"); setTimeout(() => c.classList.add("show"), 1300); }, 8500); }
  const miniIO = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { miniCards.forEach((c, i) => setTimeout(() => c.classList.add("show"), rmotion ? 0 : 500 + i * 300)); miniIO.disconnect(); } }), { threshold: 0.3 });
  miniIO.observe(mini);
  const ritual = $("#ritual"); const ritIO = new IntersectionObserver((es) => es.forEach((e) => ritual.classList.toggle("live", e.isIntersecting)), { threshold: 0.2 }); ritIO.observe(ritual);

  const ballWrap = $(".ball-wrap"), ball = $(".ball");
  ["mist", "mist b"].forEach((c) => { const m = document.createElement("span"); m.className = c; ball.appendChild(m); });
  for (let i = 0; i < 16; i++) { const s = document.createElement("span"); s.className = "spk"; s.style.left = 12 + Math.random() * 76 + "%"; s.style.top = 25 + Math.random() * 60 + "%"; s.style.setProperty("--d", 4 + Math.random() * 4 + "s"); s.style.setProperty("--dl", -Math.random() * 6 + "s"); s.style.setProperty("--dx", (Math.random() * 30 - 15) + "px"); ball.appendChild(s); }
  const vision = document.createElement("div"); vision.className = "vision"; vision.innerHTML = KINDS.map((k) => `<svg viewBox="0 0 100 110">${GLYPH[k]}</svg>`).join(""); ballWrap.appendChild(vision);
  const rip = document.createElement("span"); rip.className = "ripple"; ballWrap.appendChild(rip);
  ballWrap.addEventListener("click", () => { ballWrap.classList.remove("ping"); void ballWrap.offsetWidth; ballWrap.classList.add("ping"); });
  ballWrap.addEventListener("mouseenter", () => { ballWrap.classList.remove("ping"); void ballWrap.offsetWidth; ballWrap.classList.add("ping"); });

  /* zodiac wheel */
  (() => {
    const signs = ["♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓"];
    let s = '<svg viewBox="0 0 400 400" fill="none" stroke="#D6A044" stroke-width="1">';
    [190, 170, 120, 70].forEach((r) => { s += `<circle cx="200" cy="200" r="${r}"/>`; });
    for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; s += `<line x1="${200 + Math.cos(a) * 170}" y1="${200 + Math.sin(a) * 170}" x2="${200 + Math.cos(a) * 190}" y2="${200 + Math.sin(a) * 190}"/>`; const b = ((i + .5) / 12) * Math.PI * 2; s += `<text x="${200 + Math.cos(b) * 145}" y="${208 + Math.sin(b) * 145}" font-size="20" text-anchor="middle" fill="#D6A044" stroke="none">${signs[i]}︎</text>`; }
    s += '<path d="M200 130l11 55 55 15-55 15-11 55-11-55-55-15 55-15z" stroke-width="1.2"/></svg>';
    $("#zodiac").innerHTML = s;
  })();


  /* ---------- animated scenes for the service panels ---------- */
  const SCENE_HEAD = (id) => `<svg viewBox="0 0 320 220" role="img" aria-hidden="true"><defs><radialGradient id="g${id}"><stop offset="0" stop-color="#FFE9A8" stop-opacity=".8"/><stop offset="1" stop-color="#FFE9A8" stop-opacity="0"/></radialGradient><radialGradient id="v${id}"><stop offset="0" stop-color="#9b5de5" stop-opacity=".7"/><stop offset="1" stop-color="#9b5de5" stop-opacity="0"/></radialGradient><radialGradient id="f${id}" cx=".5" cy=".75" r=".7"><stop offset="0" stop-color="#fff8d8"/><stop offset=".4" stop-color="#ffd36b"/><stop offset="1" stop-color="#ff7a1e" stop-opacity="0"/></radialGradient></defs>`;
  const heartPath = "M0 14C-22 -2 -14 -22 0 -10 14 -22 22 -2 0 14z";
  const SCENE = {
    cards: (t) => `${SCENE_HEAD("c")}<ellipse cx="160" cy="196" rx="110" ry="12" fill="rgba(214,160,68,.18)"/><circle cx="160" cy="104" r="86" fill="url(#gc)" class="rpulse2"/>
      ${[[-16, 86, "cups", -1.2], [0, 160, "swords", -2.4], [16, 234, "wands", -3.6]].map(([r, x, k, d]) => `<g transform="translate(${x} 116) rotate(${r})"><g class="cflip" style="animation-delay:${d}s"><g class="cback" style="animation-delay:${d}s"><rect x="-30" y="-50" width="60" height="100" rx="7" fill="#160c26" stroke="#D6A044" stroke-width="2"/><rect x="-24" y="-44" width="48" height="88" rx="4" fill="none" stroke="#D6A044" stroke-opacity=".4"/><path d="M5 -14a16 16 0 1 0 4 28 13 13 0 0 1-4-28z" fill="none" stroke="#F3CF86" stroke-width="2"/></g><g class="cfront" style="animation-delay:${d}s"><rect x="-30" y="-50" width="60" height="100" rx="7" fill="#26307a" stroke="#F3CF86" stroke-width="2"/><g transform="translate(-18 -20) scale(.36)">${GLYPH[k]}</g></g></g></g>`).join("")}
      ${Array.from({ length: 10 }, (_, i) => `<circle class="twinkle" cx="${30 + ((i * 61) % 260)}" cy="${20 + ((i * 47) % 150)}" r="1.8" fill="#F3CF86" style="animation-delay:${-i * 0.35}s"/>`).join("")}</svg>`,
    pentacle: (t) => `${SCENE_HEAD("m")}<rect x="0" y="0" width="160" height="220" fill="url(#gm)" opacity=".55"/><rect x="160" y="0" width="160" height="220" fill="url(#vm)" opacity=".75"/>
      <line x1="160" y1="10" x2="160" y2="210" stroke="#D6A044" stroke-opacity=".35" stroke-dasharray="3 6"/>
      <g class="rspin2"><circle cx="160" cy="104" r="64" fill="none" stroke="#D6A044" stroke-width="1.2" stroke-dasharray="3 8"/></g><circle cx="160" cy="104" r="54" fill="none" stroke="#D6A044" stroke-width="1.3"/>
      <polyline class="sdraw" pathLength="1000" points="${[0, 2, 4, 1, 3, 0].map((k) => [160 + Math.cos(((-90 + k * 72) * Math.PI) / 180) * 54, 104 + Math.sin(((-90 + k * 72) * Math.PI) / 180) * 54].map((n) => n.toFixed(1)).join(",")).join(" ")}" fill="rgba(214,160,68,.07)" stroke="#F3CF86" stroke-width="2.2" stroke-linejoin="round"/>
      <g transform="translate(60 150)"><rect x="-8" y="0" width="16" height="44" rx="3" fill="#f3e6c8"/><g class="rflame2"><ellipse cx="0" cy="-12" rx="7" ry="13" fill="url(#fm)"/><circle cx="0" cy="-12" r="22" fill="url(#gm)" opacity=".8"/></g>${[0, 1, 2].map((i) => `<path class="wisp" d="M0 -34q-8-12 0-24q8-12 0-24" stroke="#fff" stroke-opacity=".5" stroke-width="2" fill="none" style="animation-delay:${-i * 1.1}s"/>`).join("")}</g>
      <g transform="translate(260 150)"><rect x="-8" y="0" width="16" height="44" rx="3" fill="#15101c" stroke="#9aa0b8" stroke-width="1"/><g class="rflame2" style="animation-delay:-.6s"><ellipse cx="0" cy="-12" rx="7" ry="13" fill="#d9c8ff"/><circle cx="0" cy="-12" r="24" fill="url(#vm)" opacity=".9"/></g>${[0, 1, 2].map((i) => `<path class="wisp" d="M0 -34q-8-12 0-24q8-12 0-24" stroke="#c9a8ff" stroke-opacity=".5" stroke-width="2" fill="none" style="animation-delay:${-i * 1.1 - 0.5}s"/>`).join("")}</g>
      <text x="60" y="210" text-anchor="middle" font-family="Cinzel, serif" font-size="11" letter-spacing="2" fill="#F3CF86">${t.scene_white}</text><text x="260" y="210" text-anchor="middle" font-family="Cinzel, serif" font-size="11" letter-spacing="2" fill="#d9c8ff">${t.scene_black}</text>
      ${Array.from({ length: 12 }, (_, i) => `<circle class="rspark2" cx="${120 + ((i * 29) % 80)}" cy="140" r="1.6" fill="#FFE9A8" style="animation-delay:${-i * 0.5}s"/>`).join("")}</svg>`,
    heart: (t) => `${SCENE_HEAD("h")}<circle cx="160" cy="104" r="84" fill="url(#gh)" class="rpulse2" opacity=".6"/><g class="rspin2"><ellipse cx="160" cy="108" rx="96" ry="40" fill="none" stroke="#D6A044" stroke-opacity=".5" stroke-dasharray="3 7"/></g>
      <g transform="translate(120 108)"><g class="hl"><path d="${heartPath}" fill="#e0457b" stroke="#ffd1e1" stroke-width="1.5" transform="scale(1.6)"/></g></g><g transform="translate(200 108)"><g class="hr"><path d="${heartPath}" fill="#c1121f" stroke="#ffd1e1" stroke-width="1.5" transform="scale(1.6)"/></g></g>
      ${Array.from({ length: 9 }, (_, i) => `<path class="hrt" d="${heartPath}" transform="translate(${100 + i * 15} 170) scale(.28)" fill="#ff8fb3" style="animation-delay:${-i * 0.55}s"/>`).join("")}</svg>`,
    shield: (t) => `${SCENE_HEAD("s")}<circle cx="160" cy="108" r="80" fill="url(#gs)" class="rpulse2" opacity=".5"/>
      ${[0, 1, 2].map((i) => `<circle class="dome" cx="160" cy="108" r="70" fill="none" stroke="#9fd0ff" stroke-width="1.8" style="animation-delay:${-i * 1.2}s"/>`).join("")}<g class="rspin2"><circle cx="160" cy="108" r="78" fill="none" stroke="#F3CF86" stroke-width="1.2" stroke-dasharray="4 8"/></g>
      <path d="M160 52l50 18v40c0 34-22 54-50 64-28-10-50-30-50-64V70z" fill="rgba(214,160,68,.22)" stroke="#F3CF86" stroke-width="3" stroke-linejoin="round"/><path d="M138 112l16 16 30-32" fill="none" stroke="#FFE9A8" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" class="check"/>
      ${Array.from({ length: 10 }, (_, i) => `<circle class="twinkle" cx="${40 + ((i * 67) % 240)}" cy="${20 + ((i * 53) % 170)}" r="1.8" fill="#9fd0ff" style="animation-delay:${-i * 0.4}s"/>`).join("")}</svg>`,
    clover: (t) => `${SCENE_HEAD("l")}<circle cx="160" cy="112" r="84" fill="url(#gl)" class="rpulse2" opacity=".55"/>
      <g class="breathe" transform="translate(160 106)">${[[-18, -18], [18, -18], [-18, 18], [18, 18]].map(([x, y]) => `<path d="M0 0C${x * 1.8} ${y * 0.2} ${x * 1.9} ${y * 2.1} ${x * 0.2} ${y * 1.6}C${-x * 0.1} ${y * 1.2} 0 ${y * 0.4} 0 0z" fill="#3fa75a" stroke="#1d6b34" stroke-width="2"/>`).join("")}<path d="M0 6Q4 50 -8 78" stroke="#1d6b34" stroke-width="4" fill="none" stroke-linecap="round"/></g>
      ${Array.from({ length: 7 }, (_, i) => `<g class="coin" style="animation-delay:${-i * 0.8}s" transform="translate(${50 + i * 36} 0)"><ellipse cx="0" cy="0" rx="9" ry="9" fill="#F3CF86" stroke="#8a5a1c" stroke-width="1.5"/><ellipse cx="0" cy="0" rx="5" ry="5" fill="none" stroke="#8a5a1c" stroke-width="1"/></g>`).join("")}
      ${Array.from({ length: 8 }, (_, i) => `<path class="twinkle" d="M${30 + ((i * 71) % 270)} ${24 + ((i * 41) % 150)}l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#FFE9A8" style="animation-delay:${-i * 0.45}s"/>`).join("")}</svg>`,
    house: (t) => `${SCENE_HEAD("o")}<circle cx="250" cy="44" r="16" fill="#F3CF86" opacity=".9"/><circle cx="256" cy="40" r="15" fill="#160c26"/>
      <ellipse cx="160" cy="190" rx="120" ry="10" fill="rgba(214,160,68,.15)"/><circle cx="160" cy="120" r="78" fill="url(#go)" class="rpulse2" opacity=".4"/>
      <rect x="196" y="62" width="12" height="30" fill="#6a4a3a"/>${[0, 1, 2].map((i) => `<circle class="smk" cx="202" cy="58" r="7" fill="#cfc4ea" style="animation-delay:${-i * 1.3}s"/>`).join("")}
      <path d="M100 112L160 62l60 50z" fill="#8a3a2a" stroke="#F3CF86" stroke-width="2"/><rect x="112" y="112" width="96" height="68" fill="#3a2a5a" stroke="#F3CF86" stroke-width="2"/>
      <rect x="128" y="126" width="22" height="22" rx="2" class="win" fill="#ffd36b"/><rect x="170" y="126" width="22" height="22" rx="2" class="win" style="animation-delay:-1.1s" fill="#ffd36b"/><rect x="148" y="150" width="24" height="30" rx="3" fill="#2a1a40" stroke="#F3CF86" stroke-width="1.5"/><circle cx="167" cy="166" r="1.8" fill="#F3CF86"/>
      ${Array.from({ length: 7 }, (_, i) => `<path class="hrt" d="${heartPath}" transform="translate(${130 + i * 10} 100) scale(.24)" fill="#ff8fb3" style="animation-delay:${-i * 0.7}s"/>`).join("")}
      ${Array.from({ length: 10 }, (_, i) => `<circle class="twinkle" cx="${24 + ((i * 59) % 270)}" cy="${16 + ((i * 43) % 100)}" r="1.6" fill="#F3CF86" style="animation-delay:${-i * 0.4}s"/>`).join("")}</svg>`,
  };
  const SVC_KEYS = ["cards", "pentacle", "heart", "shield", "clover", "house"];
  const svcModal = $("#svc-modal");
  function openSvc(i) {
    const t = T[lang], k = SVC_KEYS[i], [, title] = t.services[i], [p1, p2] = t.svcdetail[i];
    $("#svc-scene").innerHTML = SCENE[k](t); $("#svc-title").textContent = title;
    $("#svc-body").innerHTML = `<p>${p1}</p><p>${p2}</p><h4>${t.steps_title}</h4><ol class="steps">${t.steps.map((s) => `<li>${s}</li>`).join("")}</ol><a class="btn gold" href="${waUrl(lang)}" target="_blank" rel="noopener">${t.svc_cta}</a><p class="svc-note">${t.svc_note}</p>`;
    svcModal.classList.add("open"); $("#svc-close").focus();
  }
  const closeSvc = () => svcModal.classList.remove("open");
  $("#svc-close").addEventListener("click", closeSvc); svcModal.addEventListener("click", (e) => { if (e.target === svcModal) closeSvc(); }); document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeSvc(); });
  document.addEventListener("click", (e) => { const b = e.target.closest("[data-svc]"); if (b) openSvc(Number(b.dataset.svc)); });
  const GAL = ["altar-candles", "river", "night", "altar-skull", "conch", "room"];
  function render() {
    const t = T[lang];
    $("#svc-grid").innerHTML = t.services.map(([ic, h, p], i) => `<button type="button" class="card svc reveal in" data-svc="${i}" data-k="${ic}" aria-label="${h}: ${t.svc_more}"><div class="icon ic-${ic}">${icon(ic)}</div><h3>${h}</h3><p>${p}</p><span class="more">${t.svc_more} <i aria-hidden="true">→</i></span></button>`).join("");
    $("#hero-icons").innerHTML = t.heroicons.map(([ic, l], i) => `<button type="button" class="hi ic-${ic}" data-svc="${i}" aria-label="${l}: ${t.svc_more}">${icon(ic)}<span>${l}</span></button>`).join("");
    $("#why-grid").innerHTML = t.why.map(([ic, l]) => `<div class="why reveal in"><div class="icon">${icon(ic)}</div><h3>${l}</h3></div>`).join("");
    $("#t-grid").innerHTML = t.testi.map((q) => `<figure class="t-card reveal in"><p>${q}</p><small>${t.testi_tag}</small></figure>`).join("");
    $("#gallery-grid").innerHTML = GAL.map((n, i) => `<button type="button" class="g g${i + 1}" data-src="images/${n}.jpg" aria-label="${t.g_open}: ${t.gallery[i]}"><img src="images/${n}.jpg" alt="${t.gallery[i]}" loading="lazy" decoding="async"></button>`).join("");
    $$("[data-alt]").forEach((im) => { im.alt = t[im.dataset.alt] || ""; });
    $$(".ctitle").forEach((el) => { el.textContent = t.cardnames[el.dataset.k]; });
    $$(".tcard").forEach((c) => c.setAttribute("aria-label", t.cardnames[c.dataset.kind] + " — " + t.cardhint));
    $("#magic-chips").innerHTML = t.magic_chips.map((c) => `<span class="chip">${c}</span>`).join("");
    $("#tarot-list").innerHTML = t.tarot_list.map((l) => `<li>${icon("star").replace("<svg", '<svg fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"')}<span>${l}</span></li>`).join("");
  }

  function setLang(l, instant) {
    lang = l; const t = T[l];
    const apply = () => {
      document.documentElement.lang = l; document.title = t.title;
      $('meta[name="description"]').setAttribute("content", t.desc);
      $('meta[property="og:title"]').setAttribute("content", t.title); $('meta[property="og:description"]').setAttribute("content", t.desc); $('meta[property="og:locale"]').setAttribute("content", l === "ro" ? "ro_RO" : "en_GB");
      $$("[data-i18n]").forEach((el) => { const k = el.dataset.i18n; if (t[k] != null) el.textContent = t[k]; });
      $$("[data-wa]").forEach((a) => { a.href = waUrl(l); });
      $$("[data-wa-fixed]").forEach((a) => { a.href = waUrl(a.dataset.waFixed); });
      $$(".lang button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.lang === l)));
      $(".cards-stage").setAttribute("aria-label", t.fanlabel);
      $(".fab").setAttribute("aria-label", l === "ro" ? "Scrie pe WhatsApp" : "Chat on WhatsApp");
      $("#burger").setAttribute("aria-label", l === "ro" ? "Meniu" : "Menu"); $("#menu").setAttribute("aria-label", l === "ro" ? "Navigație principală" : "Main navigation");
      render();
      try { localStorage.setItem("sofia-lang", l); } catch (e) { /* ignore */ }
    };
    if (instant) { apply(); return; }
    document.body.classList.add("switching"); setTimeout(() => { apply(); document.body.classList.remove("switching"); }, 220);
  }
  $$(".lang button").forEach((b) => b.addEventListener("click", () => setLang(b.dataset.lang)));
  setLang(lang, true);

  /* ---------- nav, modal, reveal ---------- */
  const menu = $("#menu"), burger = $("#burger");
  burger.addEventListener("click", () => { const o = menu.classList.toggle("open"); burger.setAttribute("aria-expanded", String(o)); });
  $$("#menu a").forEach((a) => a.addEventListener("click", () => { menu.classList.remove("open"); burger.setAttribute("aria-expanded", "false"); }));
  const modal = $("#modal");
  $$("[data-modal]").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); const [h, ps] = T[lang].modal[a.dataset.modal]; $("#modal-title").textContent = h; $("#modal-body").innerHTML = ps.map((p) => `<p>${p}</p>`).join(""); modal.classList.add("open"); $("#modal-close").focus(); }));
  const closeModal = () => modal.classList.remove("open");
  $("#modal-close").addEventListener("click", closeModal); modal.addEventListener("click", (e) => { if (e.target === modal) closeModal(); }); document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });
  const lb = $("#lightbox"), lbImg = $("#lb-img");
  document.addEventListener("click", (e) => { const g = e.target.closest(".g"); if (!g) return; lbImg.src = g.dataset.src; lbImg.alt = g.querySelector("img").alt; lb.classList.add("open"); $("#lb-close").focus(); });
  const closeLb = () => lb.classList.remove("open"); $("#lb-close").addEventListener("click", closeLb); lb.addEventListener("click", (e) => { if (e.target === lb) closeLb(); }); document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeLb(); });
  $("#year").textContent = new Date().getFullYear();

  const io = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 }) : null;
  $$(".reveal").forEach((el) => (io ? io.observe(el) : el.classList.add("in")));
  const links = $$("#menu a"), secs = links.map((a) => $(a.getAttribute("href")));
  const spy = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) links.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === "#" + e.target.id)); }), { rootMargin: "-40% 0px -55% 0px" });
  secs.forEach((s) => s && spy.observe(s));

  /* ---------- subtle parallax on the card fan ---------- */
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const stage = $(".cards-stage");
  if (!reduce && matchMedia("(hover: hover)").matches) {
    stage.addEventListener("mousemove", (e) => { const r = stage.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5; fan.style.transform = `rotateY(${x * 10}deg) rotateX(${-y * 8}deg)`; });
    stage.addEventListener("mouseleave", () => { fan.style.transform = ""; });
  }

  /* ---------- floating stars ---------- */
  const cv = $("#stars"), cx = cv.getContext("2d"); let W, H; const P = [];
  const size = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; }; size(); addEventListener("resize", size);
  for (let i = 0; i < 70; i++) P.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.4 + 0.3, s: Math.random() * 0.00006 + 0.00002, p: Math.random() * 6.28, c: Math.random() > 0.7 ? "243,207,134" : "200,170,255" });
  function draw(t) {
    cx.clearRect(0, 0, W, H);
    for (const q of P) { const a = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(t * 0.001 * (0.6 + q.r) + q.p)); cx.fillStyle = `rgba(${q.c},${a})`; cx.beginPath(); cx.arc(q.x * W, ((q.y - t * q.s) % 1 + 1) % 1 * H, q.r, 0, 6.283); cx.fill(); }
    if (!reduce) requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);
})();
